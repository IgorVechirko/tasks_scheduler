#include "Common.h"

namespace TasksScheduler
{
	std::recursive_mutex Console::_outputLocker;
}